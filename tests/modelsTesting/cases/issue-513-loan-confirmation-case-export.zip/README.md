﻿# Issue 513 Loan Confirmation Case Export

Use this export as a comparison fixture for case/document-generation tests.

Files:
- case-export.json: machine-readable prompt, expected behavior, assertions, and artifact map.
- fixed-assistant-answer.txt: expected assistant answer after the fix.
- generated-document.txt: expected generated legal-document body.
- generated-document.pdf: rendered generated document.
- fixed-answer.png: screenshot of the fixed answer with document link.
- fixed-answer.html: local HTML view used for screenshot.
- prod-before-screenshot.png: original production failure screenshot, if available.
